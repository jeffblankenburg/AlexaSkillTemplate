const HelpIntent = require("./HelpIntent");
const StopIntent = require("./StopIntent");

module.exports = {
    HelpIntent,
    StopIntent,
};
