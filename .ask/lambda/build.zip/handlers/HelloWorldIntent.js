function HelloWorldIntent(handlerInput) {
    const speakOutput = 'Hello World!';
        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
}

module.exports = HelloWorldIntent;