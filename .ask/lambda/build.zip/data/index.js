const getRandomSpeech = require("./getRandomSpeech");
const getUserRecord = require("./getUserRecord");

module.exports = {
  getRandomSpeech,
  getUserRecord,
};
